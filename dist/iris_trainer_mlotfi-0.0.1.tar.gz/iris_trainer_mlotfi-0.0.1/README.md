# iris_trainer
Training a model on the iris dataset.
